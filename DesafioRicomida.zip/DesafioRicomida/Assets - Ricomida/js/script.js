

$(function(){
    // métodos de jQuery...
   

});